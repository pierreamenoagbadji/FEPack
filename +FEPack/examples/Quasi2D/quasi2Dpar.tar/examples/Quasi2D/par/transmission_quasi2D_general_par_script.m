transmission_quasi2D_general_par(1);
transmission_quasi2D_general_par(2);
transmission_quasi2D_general_par(3);
transmission_quasi2D_general_par(4);
transmission_quasi2D_general_par(5);